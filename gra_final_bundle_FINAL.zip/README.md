# GrA — Sovereign Intelligence OS (Final Bundle)

هذا التجميع يحتوي على:

- **app/**: مشروع C++/Qt6 لواجهة GrA (Sovereign، بدون سحابة).
- **ops/**: خدمة Node/Express `actions-api` (CommonJS) + ملف systemd + تهيئة Nginx موحّدة.
- **docs/**: خطوات بناء وتشغيل (Windows/Ubuntu).

> الهدف: نسخة تشغيلية وسيادية (Zero-Cloud) مع واجهات صحية وOpenAPI صالح.

