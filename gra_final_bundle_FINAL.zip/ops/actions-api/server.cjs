import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import fs from 'fs';
dotenv.config();

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(helmet());

// CORS allowlist
const allowlist = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const corsOptions = {
  origin: function (origin, callback) {
    if (!origin || allowlist.length === 0 || allowlist.includes(origin)) return callback(null, true);
    return callback(new Error('Not allowed by CORS'));
  },
  credentials: false,
};
app.use(cors(corsOptions));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10),
  max: parseInt(process.env.RATE_LIMIT_MAX || '300', 10),
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Liveness
app.get('/health', (_, res) => res.json({ ok: true }));

// Metrics (Prometheus)
let promClient;
if ((process.env.ENABLE_METRICS || 'true') === 'true') {
  const pc = await import('prom-client');
  promClient = pc.default || pc;
  promClient.collectDefaultMetrics();
  app.get('/metrics', async (_, res) => {
    res.set('Content-Type', promClient.register.contentType);
    res.end(await promClient.register.metrics());
  });
}

// JWT protect
function requireJWT(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing_token' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET, {
      issuer: process.env.JWT_ISSUER,
      audience: process.env.JWT_AUDIENCE,
    });
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid_token' });
  }
}

// Protected sample
app.get('/v1/secure/ping', requireJWT, (req, res) => {
  res.json({ pong: true, sub: req.user.sub });
});

// Serve OpenAPI if present
if (fs.existsSync('./openapi.json')) {
  app.get('/openapi.json', (_, res) => res.sendFile(process.cwd() + '/openapi.json'));
}

const HOST = process.env.HOST || '127.0.0.1';
const PORT = parseInt(process.env.PORT || '7070', 10);
app.listen(PORT, HOST, () => {
  console.log(`✅ API running on http://${HOST}:${PORT}`);
});
